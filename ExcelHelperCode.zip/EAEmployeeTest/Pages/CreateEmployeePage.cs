﻿using EAAutoFramework.Base;

namespace EAEmployeeTest.Pages
{
    class CreateEmployeePage : BasePage
    {


    }
}
